# Solid Fonts

Solid uses Proxima Nova and Caponi. If you wish to use these fonts please support typographers and buy them.
